require "import"
import "android.widget.*"
import "android.view.*"



home="api.bilibili.com"
fans="relation/stat"
person="space/acc/info"